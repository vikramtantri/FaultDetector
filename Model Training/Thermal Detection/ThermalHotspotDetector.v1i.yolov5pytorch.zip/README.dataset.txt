# ThermalHotspotDetector > 2022-11-26 6:45pm
https://universe.roboflow.com/object-detection/thermalhotspotdetector

Provided by a Roboflow user
License: CC BY 4.0

